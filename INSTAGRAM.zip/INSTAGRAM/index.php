<!DOCTYPE html>
<html lang="en">
<head>
  <title>Instagram-Like Navbar</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <!-- Font Awesome for icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<style>
    html, body {
      margin: 0;
      padding: 0;
      height: 100%;
      background-color: #000;
      color: white;
      font-family: Arial, sans-serif;
    }
    .container-fluid {
      padding: 0;
      height: 100%;
      display: flex;
      align-items: flex-start;
    }
    .left-navbar {
      width: 17%;
      height: 100vh; /* Set navbar height to full viewport height */
      border-right: 1px solid #262626;
      padding: 20px;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      color: white;
      position: fixed; /* Fix the navbar in place */
      top: 0; /* Fix it to the top */
      left: 0; /* Align to the left */
      overflow-y: auto; /* Enable vertical scrolling if necessary */
    }
    .nav-item {
      display: flex;
      align-items: center;
      color: white;
      padding: 12px 20px; /* Adjust padding for button-like appearance */
      font-size: 16px;
      text-decoration: none; /* Remove underline */
      border-radius: 8px; /* Rounded corners */
      transition: background-color 0.3s ease; /* Smooth transition */
      width: 100%; /* Full width on hover */
    }
    .nav-item:hover {
      background-color: #1A1A1A; /* Change background color on hover */
      color: #b3b3b3; /* Optional: Change text color on hover */
    }
    .nav-icon {
      margin-right: 15px; /* Increased space between icon and text */
      font-size: 20px;
    }
    .notification-badge {
      background-color: red;
      color: white;
      font-size: 10px;
      border-radius: 50%;
      padding: 2px 6px;
      margin-left: 5px;
    }
    .bottom-nav {
      margin-top: auto;
      width: 100%;
    }
    .profile-section {
      display: flex;
      align-items: center;
      padding-top: 20px;
      border-top: 1px solid #262626;
      width: 100%;
    }
    .profile-section img {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      margin-right: 10px;
    }
    .logo {
      font-family: 'Segoe UI', sans-serif;
      font-size: 24px;
      font-weight: bold;
      margin-bottom: 20px;
    }
    .container-main {
      flex: 1; /* Allow the main content to take the remaining space */
      margin-left: 17%; /* Offset for the fixed navbar */
      display: flex;
      padding: 20px;
      height: 100vh; /* Set the height for the main container */
      overflow-y: auto; /* Enable scrolling for the main container */
    }
    .feed {
      flex: 2; /* Main feed takes more space */
      margin-right: 20px;
      display: flex;
      flex-direction: column;
      align-items: center; /* Center the posts */
    }
    .post {
      background-color: #000000; /* Dark background for posts */
      border-radius: 8px;
      margin-bottom: 60px;
      padding: 10px;
      color: white;
      width: 650px; /* Fixed width for posts */
      height: 800px; /* Fixed width for posts */
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Optional: shadow for better visibility */
    }
    .post-header {
      display: flex;
      align-items: center;
    }
    .post-user-img {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      margin-right: 10px;
    }
    .post-image {
      width: 100%; /* Responsive to post width */
      height: 100%; /* Fixed height for posts */
      border-radius: 8px;
      margin: 10px 0;
    }
    .post-actions {
      display: flex;
      justify-content:;
      margin: 10px 0;
    }
    .button {
      background: none;
      border: none;
      color: white;
      cursor: pointer;
    }
    .sidebar {
      width: 25%; /* Sidebar width */
      background-color: #1a1a1a;
      border-radius: 8px;
      padding: 15px;
      overflow-y: auto; /* Enable vertical scrolling if necessary */
      height: 100vh; /* Set navbar height to full viewport height */
      
    }
    .suggestions {
      margin-top: 20px;
    }
    .suggested-user {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
    }
    .suggested-user-img {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      margin-right: 10px;
    }
    .follow-button {
      background-color: #0095f6; /* Instagram blue */
      color: white;
      border: none;
      border-radius: 5px;
      padding: 5px 10px;
      cursor: pointer;
    }
</style>
<body>
    <div class="container-fluid">
        <div class="left-navbar">
            <!-- Logo -->
            <img src="images/instalogo.png" alt="Instagram Logo" style="width: 140px; margin-bottom: 20px; margin-left: -20px;">
            
            <!-- Navigation Items -->
            <a href="#" class="nav-item"><i class="fas fa-home nav-icon"></i> Home</a>
            <br>
            <a href="#" class="nav-item"><i class="fas fa-search nav-icon"></i> Search</a>
            <br>
            <a href="#" class="nav-item"><i class="fas fa-compass nav-icon"></i> Explore</a>
            <br>
            <a href="#" class="nav-item"><i class="fas fa-film nav-icon"></i> Reels</a>
            <br>
            <a href="#" class="nav-item"><i class="fas fa-envelope nav-icon"></i> Messages <span class="notification-badge">3</span></a>
            <br>
            <a href="#" class="nav-item"><i class="fas fa-heart nav-icon"></i> Notifications</a>
            <br>
            <a href="#" class="nav-item"><i class="fas fa-plus-square nav-icon"></i> Create</a>
            <br>
            <a href="#" class="nav-item"><i class="fas fa-user-circle nav-icon"></i> Profile</a>

            <!-- Bottom Navigation Items -->
            <div class="bottom-nav">
                <a href="#" class="nav-item"><i class="fas fa-comments nav-icon"></i> Threads <span class="notification-badge">9+</span></a>
                <a href="#" class="nav-item"><i class="fas fa-bars nav-icon"></i> More</a>
            </div>
        </div>
        <div class="container-main">
            <div class="feed">
            <div class="post">
                    <div class="post-header">
                        <img src="images/dv.png" alt="User 1" class="post-user-img">
                        <div class="post-user-info">
                            <strong>dron_vashisth</strong>
                            <p>2 hours ago</p>
                        </div>
                    </div>
                    <img src="images/dvpo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
    
                    <div class="post-description">
                        <strong>dron_vashisth LOOKING SMART</strong> 
                    </div>
                </div>
<br><br><br><br>
                  <div class="post">
                    <div class="post-header">
                        <img src="images/jattudp.png" alt="User 1" class="post-user-img">
                        <div class="post-user-info">
                            <strong>nannu_0064</strong>
                            <p>2 hours ago</p>
                        </div>
                    </div>
                    <img src="images/jattupo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
    
                    <div class="post-description">
                        <strong>CHILLIN IN VIBES</strong> 
                    </div>
                </div>
<br><br><br><br>
                <div class="post">
                    <div class="post-header">
                        <img src="images/jshnpr.png" alt="User 1" class="post-user-img">
                        <div class="post-user-info">
                            <strong>j.xdeep</strong>
                            <p>2 hours ago</p>
                        </div>
                    </div>
                    <img src="images/jshnpo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
    
                    <div class="post-description">
                        <strong>CHILLIN IN VIBES</strong> 
                    </div>
                </div>
<br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/vnshpr.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>vanshuufr</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/vnshpo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>CHILLIN IN VIBES</strong> 
                    </div>
                </div>
                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/krnpf.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>karan_jassal_0810</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/krnpo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>CHILLIN IN VIBES</strong> 
                    </div>
                </div>
                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/gurmanpf.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>gurmanraj_s</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/gurmanpo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>CHILLIN IN VIBES</strong> 
                    </div>
                </div>
                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/gurnurdp.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>gurnoor3303</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/gurnurpo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>CHILLIN IN VIBES</strong> 
                    </div>
                </div>
                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/powdp.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>sahotaa_powell</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/powpo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>CHILLIN IN VIBES</strong> 
                    </div>
                </div>
                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/kaldp.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>kalacriti</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/kalpo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>CHILLIN IN VIBES</strong> 
                    </div>

                </div>

                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/andp.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>ankush_2ko6</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/anpo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>ankush_2ko6 JUNGLE M MANGLE</strong> 
                    </div>
                </div>
                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/khudp.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>khushii.000x</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/khupo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>khushii.000x YO YO YO MY  BIRTHDAY</strong> 
                    </div>
                </div>
                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/kritika.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>kritika_0064</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/kripo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>kritika_0064 Calmness over chaos</strong> 
                    </div>
                </div>
                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/smidp.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>smidhi_04</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/smipo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>smidhi_04 It's all about the glow</strong> 
                    </div>
                </div>
                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/tidp.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>tiya_thukral</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/tipo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>tiya_thukral Me Time</strong> 
                    </div>
                </div>
                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/krdp.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>krish_deo_21
                            </strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/krpo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>krish_deo_21 CHILLIN IN VIBES</strong> 
                    </div>
                </div>
                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/rdp.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong> rishuu_mhajn</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/rpo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>rishuu_mhajn Balle Balle</strong> 
                    </div>
                </div>
                <br><br><br><br>
                <!-- Repeat similar structure for more posts -->
                <div class="post">
                    <div class="post-header">
                        <img src="images/gdp.png" alt="User 2" class="post-user-img">
                        <div class="post-user-info">
                            <strong>gaurish_4</strong>
                            <p>3 hours ago</p>
                        </div>
                    </div>
                    <img src="images/gpo.png" alt="Sample Post" class="post-image">
                    <div class="post-actions">
                        <button class="like-button"><img src="images/like.png"></button>
                        <button class="comment-button"><img src="images/comment.png"></i></button>
                        <button class="share-button"><img src="images/share.png"></i></button>
                    </div>
                    <div class="post-description">
                        <strong>gaurish_4 CHILLIN IN VIBES</strong> 
                    </div>
                </div>
                <br><br><br><br>
                






                
            </div>
            
            <div class="sidebar">
                <div class="suggestions">
                    <div class="suggested-user">
                        <img src="images/dv.png" alt="Suggested User" class="suggested-user-img">
                        <div>
                            <strong>dron_vashisth</strong>
                            <button class="follow-button">SWITCH</button>
                        </div>
                    </div>
                    <h4>Suggestions for you</h4>
                    <div class="suggested-user">
                        <img src="images/paras.png" alt="Suggested User" class="suggested-user-img">
                        <div>
                            <strong>parasdattkanswal_</strong>
                            <button class="follow-button">Follow</button>
                        </div>
                    </div>
                    <div class="suggested-user">
                        <img src="images/navyog.png" alt="Suggested User" class="suggested-user-img">
                        <div>
                            <strong>loteynavyog</strong>
                            <button class="follow-button">Follow</button>
                        </div>
                    </div>
                    <div class="suggested-user">
                        <img src="images/mr.png" alt="Suggested User" class="suggested-user-img">
                        <div>
                            <strong>mr_anonymous0098</strong>
                            <button class="follow-button">Follow</button>
                        </div>
                    </div>
                    <div class="suggested-user">
                        <img src="images/bhrt.png" alt="Suggested User" class="suggested-user-img">
                        <div>
                            <strong>exe.bhrt</strong>
                            <button class="follow-button">Follow</button>
                        </div>
                    </div>
                    <div class="suggested-user">
                        <img src="images/shdp.png" alt="Suggested User" class="suggested-user-img">
                        <div>
                            <strong>sharma_ldh13</strong>
                            <button class="follow-button">Follow</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
